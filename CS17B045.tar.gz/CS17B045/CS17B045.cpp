#include <iostream>
#include <bits/stdc++.h>
#include <cmath>
#include <sstream>
#include <ctime>
#include <cstdlib>
#include <fstream>
using namespace std;

// Function to convert Decimal to binary:
string convertDecimalToBinarystr(long long n){
    ostringstream str1;
    //long long result= 0;
    long long msbbit = log2(n);
    long long div = pow(2, msbbit);
    while(div != 0){
      str1 << n/div;
      n = n%div;
      div = div/2;
    }
    string result;
    result = str1.str();
    return result;
}

// Function to convert hexadecimal string to decimal:
long long hexaStrToDecimal(string str){
  long long decResult = 0;
  for(int i = 0; i < str.length(); i ++){
    // multiply result by 16 :
    decResult *= 16;
    // if the character is >= 'A' :
    if(str[i] - 65 >= 0){
      decResult += (str[i] - 65) + 10;
    }
    // if the character lies b/w '0' and '9':
    else{
      decResult += str[i] - 48;
    }
  }
  return decResult;
}

// Function to convert binary string to decimal:
long long binStrToDecimal(string str){
  long long decResult = 0;
  for(int i = 0; i < str.length(); i ++){
    // multiply result by 2:
    decResult *= 2;
    // add 1 or 0 to the result, according
    // to the current bit :
    decResult += str[i] - 48;
  }
  return decResult;
}

// Parent class to both the fully associative and set associative:
class baseCache{
protected:
  string t_str;
  string s_str;
  string b_str;

  long long cacheSize;
  long long Associativity;
  long long numBlocks;

  long long blockSize;
  long long numSet;

  long long n_blockOffset;
  long long n_setIndexBits;
  long long n_tagBits;

  long long curr_tag;
  long long curr_set;
  long long curr_bOff;
  struct block{
    long long tag;
    bool valid, dirty;
    block(){
      valid = 0;
      dirty = 0;
    }
  };
public:
  // default constructor:
  baseCache(){
  }

  // decode function:
  void decode(string hexa){
    t_str.erase();
    s_str.erase();
    b_str.erase();
    if(hexa.length() == 8){
      // Initializing fields of the address:
      n_setIndexBits =(long long) log2(numSet);
      n_blockOffset = (long long)log2(blockSize);
      n_tagBits = 32 - n_blockOffset - n_setIndexBits;

      // to find the set, block offset and tag in decimal:

      long long hexToDec = hexaStrToDecimal(hexa);
      // the binary representation of the hexadecimal (as a string):
      string bin = convertDecimalToBinarystr(hexToDec);
      //cout << bin << endl;
      //cout << bin.length() << endl;
      if(bin.length() < 32){
        ostringstream str2;
        int l = 32 - bin.length();
        for(int i = 0; i < l; i ++){
          str2 << 0;
        }
        string str_temp = str2.str();
        bin = str_temp + bin;
      }
      //cout << bin << endl;
      //cout << bin.length() << endl;
      // figuring out the bits for each field:
      for(int i = 0; i < 32; i++){

        if(i<n_tagBits){
          t_str.push_back(bin[i]);
        }
        else if(i<n_tagBits + n_setIndexBits){
          s_str.push_back(bin[i]);
        }
        else{
          b_str.push_back(bin[i]);
        }
      }
      // decimal value of the tag, setindex and blockOffset:
      curr_tag = binStrToDecimal(t_str);
      curr_set = binStrToDecimal(s_str);
      curr_bOff = binStrToDecimal(b_str);
    }
    return;
  }

  // Function to print the values of the tag, set # and block Offset:
  void printVars(){
    cout << curr_tag << " " << curr_set << " " << curr_bOff <<endl;
    return;
  }
};

// Derived class - Set associative cache:
class SetAssCache : public baseCache{
protected:
  // Map to maintain number of compulsory misses:
  long long RP;
  map<long long, int> cmpMisses;

  long long compulsory_misses;
  long long conflict_misses;
  long long cap_misses;

  long long num_cache_accesses;
  long long num_read_accesses;
  long long num_write_accesses;

  long long num_write_misses;
  long long num_read_misses;
  long long num_total_misses;

  long long num_dirty_evicted;

  // tag array:
  vector<list<block> > tag_array;

  // read write flag:
  bool rwflag;

  // Pseudo LRU bit space:
  vector<vector<bool> > psl;

  // compulsory flag :
  bool cflag;

  // fullyAssociative flag:
  bool FAflag;
public:
  SetAssCache(){
  }
  // Parametrized Constructor :
  SetAssCache(int Csize, int Bsize, int Ass){

    // Initializing inputs:
    blockSize = Bsize;
    cacheSize = Csize;
    Associativity = Ass;

    // Initializing other baseCache variables:
    // Check for fully Ass:
    numBlocks = cacheSize/blockSize;
    if(Associativity > 0){
      numSet = numBlocks/Associativity;
      FAflag = false;
    }
    else if(Associativity == 0){
      FAflag = true;
      numSet = 1;
      Associativity = numBlocks;
    }
    // Initializing SetAssCache variables:
    num_write_accesses = 0;
    num_read_accesses = 0;
    num_cache_accesses = 0;

    num_read_misses = 0;
    num_write_misses = 0;
    num_total_misses = 0;

    compulsory_misses = 0;
    conflict_misses = 0;
    cap_misses = 0;
    num_dirty_evicted = 0;

    tag_array.resize(numSet);
    for(long long i = 0; i < tag_array.size() ; i ++){
      tag_array[i].resize(Associativity);
    }

    psl.resize(numSet);
    for(long long i = 0; i < numSet; i ++){
      psl[i].resize(Associativity);
      for(int j = 0; j < Associativity; j ++){
        psl[i][j] = false;
      }
    }
  }

  // LRU Replacement, report hit or miss:
  void Find(string address, int Rp){
    cflag = false;
    RP = Rp;

    // Increment #accesses:
    num_cache_accesses++;

    // Decode sets the current tag, set index and block offset
    decode(address);

    // Set the read write flag according to first bit of the tag:
    //cout << (int)(curr_tag/pow(2, n_tagBits-1)) << endl;
    //cout << curr_tag/pow(2, n_tagBits - 1) << endl;
    if( (int)(curr_tag/pow(2, n_tagBits - 1)) == 0 ){
      rwflag = 0;
      // Increment the read accesses:
      num_read_accesses++;
    }
    else
    {
      rwflag = 1;
      // Increment the write accesses:
      num_write_accesses++;
      // Change the curr_tag's first bit:
      string binTag = convertDecimalToBinarystr(curr_tag);
      string str1 = binTag.substr(1, binTag.length() - 1);
      ostringstream str2;
      str2 << 0 << str1;
      binTag = str2.str();
      curr_tag = binStrToDecimal(binTag);
    }
    long long blockId = 0;
    blockId = curr_tag*pow(2, s_str.length()) + curr_set;
    // Go to the corresponding set in the tag array,
    // go through all blocks till a hit occurs:
    bool hit_flag = false;
    list<block>::iterator it =(tag_array[curr_set]).begin();

    long long counter = 0;
    for(; it != (tag_array[curr_set]).end() ; it ++){
      // In case there is a hit:
      if((*it).tag == curr_tag && (*it).valid == 1){
        hit_flag = true;
        block temp = (*it);
        if(rwflag){
          temp.dirty = 1;
        }
        if(Rp == 1){
          (tag_array[curr_set]).erase(it);
          (tag_array[curr_set]).push_front(temp);
        }
        if(Rp == 2){
          psl[curr_set][counter] = true;
          (tag_array[curr_set]).erase(it);
          (tag_array[curr_set]).push_front(temp);
        }
        break;
        counter ++;
      }
    }
    // In case there is a miss:
    if(hit_flag == false){
      // Increment total misses:
      num_total_misses++;

      // Increment read/write misses:
      if(rwflag){
        num_write_misses++;
      }
      else{
        num_read_misses++;
      }
      // If the last block is invalid (in this case occurs only at the beginning)
      // Increment the compulsory_misses:
      if(cmpMisses.count(blockId) == 0){
        cmpMisses.insert(pair<long long, int>(blockId, 0));
        compulsory_misses++;
        cflag = true;
      }

      // Cache replacement policy:
      if(Rp == 0){
        Ran();
      }
      else if(Rp == 1){
        LRU();
      }
      else if(Rp == 2){
        PLRU();
        /*
        // Check if the whole of the set has MRU 1:
        bool fullFlag = true;
        for(int i = 0; i < Associativity; i ++){
          if(psl[curr_set][i] != true){
            fullFlag = false;
            break;
          }
        }
        // If yes, then reset to 0:
        if(fullFlag){
          for(int i = 0; i < Associativity; i ++){
            psl[curr_set][i] = false;
          }
        }
        */
      }
    }
    return;
  }

  void LRU(){
    list<block>::iterator it;
    it = (tag_array[curr_set]).end();
    it--;
    // Else the miss must be a conflict miss:
    if((*it).valid == 1 && !cflag){
      if(!FAflag){
        conflict_misses++;
      }
      else{
        cap_misses++;
      }
    }

    // If the last block was changed by write:
    if((*it).dirty == 1){
      num_dirty_evicted ++;
    }

    // Evict the last block:
    (tag_array[curr_set]).pop_back();

    // push the new block to the front of the list:
    block temp;
    temp.tag = curr_tag;
    if(rwflag){
      temp.dirty = 1;
    }
    temp.valid = 1;
    (tag_array[curr_set]).push_front(temp);
  }

  void Ran(){
    // find the iterator to random block:
    //srand(time(0));
    int blockInSet = (rand())%Associativity;
    list<block>::iterator it;
    it = (tag_array[curr_set]).begin();
    int i = 0;
    while(i != blockInSet){
      i++;
      it++;
    }
    // Else the miss must be a conflict miss:
    if((*it).valid == 1 && !cflag){
      if(!FAflag){
        conflict_misses++;
      }
      else{
        cap_misses++;
      }
    }

    // If the last block was changed by write:
    if((*it).dirty == 1){
      num_dirty_evicted ++;
    }

    // Evict and update with new block:
    if(rwflag){
      (*it).dirty = 1;
    }
    (*it).valid = 1;
    (*it).tag = curr_tag;
    return;
  }

  void PLRU(){

    // find the first zero bit in the line:

    int blockInSet;
    if(Associativity == 1){
      blockInSet = 0;
    }
    else{
      blockInSet = (rand())%(Associativity - 1);
      blockInSet++;
    }
    /*
    for(int i = 0; i < Associativity; i ++){
      if(psl[curr_set][i] == false){
        blockInSet = i;
        break;
      }
    }
    */
    // find the corresponding iterator:
    list<block>::iterator it;
    it = (tag_array[curr_set]).begin();
    int i = 0;
    while(i != blockInSet){
      i++;
      it++;
    }

    // Else the miss must be a conflict miss:
    if((*it).valid == 1 && !cflag){
      if(!FAflag){
        conflict_misses++;
      }
      else{
        cap_misses++;
      }
    }

    // If the last block was changed by write:
    if((*it).dirty == 1){
      num_dirty_evicted ++;
    }

    // Evict and update with new block:
    if(rwflag){
      (*it).dirty = 1;
    }
    (*it).valid = 1;
    (*it).tag = curr_tag;
    psl[curr_set][blockInSet] = true;
    block temp = (*it);
    (tag_array[curr_set]).erase(it);
    (tag_array[curr_set]).push_front(temp);
    return;

  }

  // Printing the reqd. outputs:
  void PrintOP(){
    cout << "# cache accesses:" << num_cache_accesses << endl;
    cout << "# read accesses:" << num_read_accesses << endl;
    cout << "# write accesses:" << num_write_accesses << endl;
    cout << "# cache misses:" << num_total_misses << endl;
    cout << "# read misses:" << num_read_misses << endl;
    cout << "# write misses:" << num_write_misses << endl;
    cout << "# compulsory_misses:" << compulsory_misses << endl;
    cout << "# conflict misses:" << conflict_misses << endl;
    cout << "# dirt blocks evicted:" << num_dirty_evicted << endl;
    return;
  }

  // Getting parameters:
  long long getCsize(){
    return cacheSize;
  }
  long long getBsize(){
    return blockSize;
  }
  long long getAss(){
    if(!FAflag){
    return Associativity;
    }
    else{
      return 0;
    }
  }
  long long Rp(){
    return RP;
  }
  long long cacheAcc(){
    return num_cache_accesses;
  }
  long long readAcc(){
    return num_read_accesses;
  }
  long long writeAcc(){
    return num_write_accesses;
  }
  long long cacheMiss(){
    return num_total_misses;
  }
  long long compMiss(){
    return compulsory_misses;
  }
  long long conflictMiss(){
    return conflict_misses;
  }
  long long capacityMiss(){
    return cap_misses;
  }
  long long readMiss(){
    return num_read_misses;
  }
  long long writeMiss(){
    return num_write_misses;
  }
  long long dirtyEvict(){
    return num_dirty_evicted;
  }
};


int main(){
  srand(time(0));
  ifstream myfile;
  myfile.open("input.txt");
  string str;
  long long i = 0;
  long long Csize, Bsize, Ass, Rp;
  SetAssCache C1;
  string hexAddress;
  while(getline(myfile, str)){
    //cout << str << endl;
    if(i < 4){
      if(i == 0){
        //cout << str << endl;
        stringstream ss(str);
        ss >> Csize ;
      }
      else if(i == 1){
        //cout << str << endl;
        stringstream ss(str);
        ss >> Bsize;
      }
      else if(i == 2){
        //cout << str << endl;
        stringstream ss(str);
        ss >> Ass;
      }
      else if(i == 3){
        //cout << str << endl;
        stringstream ss(str);
        ss >> Rp;
        //cout << Rp << endl;
        C1 = SetAssCache(Csize, Bsize, Ass);
      }
    }
    else{
      //cout << str << endl;
      hexAddress = str;
      C1.Find(hexAddress, Rp);
    }
    i++;
  }
  myfile.close();
  ofstream output;
  output.open("output.txt");
  for(int i = 0; i < 14; i++){
    ostringstream str1;
    switch(i){
      case 0:str1 << C1.getCsize();
      output << str1.str() + "\n";
      break;
      case 1:str1 << C1.getBsize();
      output << str1.str() + "\n";
      break;
      case 2:str1 << C1.getAss();
      output << str1.str() + "\n";
      break;
      case 3:str1 << C1.Rp();
      output << str1.str() + "\n";
      break;
      case 4:str1 << C1.cacheAcc();
      output << str1.str() + "\n";
      break;
      case 5:str1 << C1.readAcc();
      output << str1.str() + "\n";
      break;
      case 6:str1 << C1.writeAcc();
      output << str1.str() + "\n";
      break;
      case 7:str1 << C1.cacheMiss();
      output << str1.str() + "\n";
      break;
      case 8:str1 << C1.compMiss();
      output << str1.str() + "\n";
      break;
      case 9:str1 << C1.conflictMiss();
      output << str1.str() + "\n";
      break;
      case 10:str1 << C1.capacityMiss();
      output << str1.str() + "\n";
      break;
      case 11:str1 << C1.readMiss();
      output << str1.str() + "\n";
      break;
      case 12:str1 << C1.writeMiss();
      output << str1.str() + "\n";
      break;
      case 13:str1 << C1.dirtyEvict();
      output << str1.str() + "\n";
      break;
    }
  }
  output.close();
  return 0;
}
